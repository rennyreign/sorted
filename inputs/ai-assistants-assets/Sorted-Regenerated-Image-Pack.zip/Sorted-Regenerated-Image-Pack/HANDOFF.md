# Sorted image handoff

Eight independently regenerated PNG assets based on the supplied mockup. These are new reconstructions, not original source files or enlarged mockup crops.

## Files

| File | Pixels | Placement |
| --- | --- | --- |
| `website/images/hero-tradesman.png` | 1536 × 1024 | Hero background photograph |
| `website/images/assistant-phone.png` | 866 × 1816 | Hero foreground phone cutout |
| `website/images/owner-phone.png` | 1402 × 1122 | Cafe owner messaging |
| `website/images/enquiries-tradesman.png` | 1086 × 1448 | Enquiries card photograph |
| `website/images/quote-clipboard.png` | 1122 × 1402 | Quotes card photograph |
| `website/images/booking-phone.png` | 1122 × 1402 | Bookings card photograph |
| `website/images/follow-up-note.png` | 1122 × 1402 | Follow-ups card photograph |
| `website/images/owner-laptop.png` | 1672 × 941 | Owner using laptop |

## Implementation

- Place the hero photo as the background and the transparent assistant phone above it. Rebuild notification badges, icons, yellow strokes and the curved photo mask with HTML/CSS. These are interface elements, not missing photographic assets.
- Use cover for photographs and contain for the transparent phone. Apply rounded corners in CSS; masters are rectangular. Crop focal points and original region mappings are in website/asset-manifest.json.
- The Enquiries card uses its own side-facing portrait. Do not substitute the front-facing hero photo.
- Reference crops are comparison evidence only. Use website/images for the actual build.
- website/design-ir.json provides page copy and estimated structure/tokens. Exact font, responsive breakpoints and geometry remain unverified. It is a documented JSON handoff, not guaranteed compatibility with an unseen agent schema.
- Verify legal footer details, live links and final page copy before publication.

## Quality and limits

The final long edges are 1,402–1,816 px. All exceed 2× their visible display dimensions in the supplied 1024 px-wide mockup. The generator returned smaller files than the requested 1,536/2,048 px targets; no stretching or artificial enlargement was applied. For substantially larger layouts, commission larger sources.

Photos preserve the composition, clothing, light and scene while rebuilding fine details and obscured pixels. Generated people are illustrative reconstructions. The phone contains real transparent pixels; a faint edge fringe remains visible at full magnification but is negligible at the intended display size. Quote sheet small print was intentionally cleared to avoid invented business details. See qa/images.json for all per-asset differences.

Built-in image generation was used. Prompts and correction prompts are included. asset-index.jpg previews the final assets, and qa/source-comparison.jpg compares each with its exact source region.